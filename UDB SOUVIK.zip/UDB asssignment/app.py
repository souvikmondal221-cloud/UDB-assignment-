import os

from flask import Flask, jsonify, request, send_from_directory

from config.db import bootstrap_database
from routes.auth_routes import auth_bp
from routes.movies_routes import movies_bp
from routes.reviews_routes import reviews_bp


def create_app():
    app = Flask(__name__, static_folder="public", static_url_path="")

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(movies_bp, url_prefix="/movies")
    app.register_blueprint(reviews_bp, url_prefix="/reviews")

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.get("/health")
    def health_check():
        return {
            "status": "ok",
            "message": "Movie Recommendation & Review System is running."
        }

    @app.errorhandler(404)
    def spa_fallback(_error):
        if request.path.startswith(("/auth", "/movies", "/reviews", "/health")):
            return jsonify({"error": "Resource not found."}), 404
        return send_from_directory(app.static_folder, "index.html")

    return app


app = create_app()
bootstrap_database()


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_ENV") == "development")
