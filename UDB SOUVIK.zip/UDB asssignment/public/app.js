import { api } from './services/api.js';
import { getSession, saveSession, clearSession, isAuthenticated } from './services/session.js';
import { renderAuthPage } from './pages/authPage.js';
import { renderHomePage } from './pages/homePage.js';
import { renderMovieDetailsPage } from './pages/movieDetailsPage.js';
import { renderLeaderboardPage } from './pages/leaderboardPage.js';

const state = {
  session: getSession(),
  homeData: null,
  searchResults: [],
  selectedMovie: null,
  reviews: [],
  leaderboard: []
};

const appView = document.getElementById('appView');
const searchInput = document.getElementById('searchInput');
const authToggleButton = document.getElementById('authToggleButton');
const leaderboardButton = document.getElementById('leaderboardButton');

function syncAuthButton() {
  authToggleButton.textContent = isAuthenticated() ? 'Logout' : 'Login';
}

function showToast(message, type = 'info') {
  const existing = document.querySelector('.toast');
  if (existing) {
    existing.remove();
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add('visible'), 10);
  setTimeout(() => {
    toast.classList.remove('visible');
    setTimeout(() => toast.remove(), 220);
  }, 2600);
}

async function loadHomeData() {
  state.homeData = await api.getHomeSections();
}

async function loadMovieDetails(movieId) {
  const [movieResponse, reviewsResponse] = await Promise.all([
    api.getMovie(movieId),
    api.getMovieReviews(movieId)
  ]);
  state.selectedMovie = movieResponse.movie;
  state.reviews = reviewsResponse.reviews;
}

async function loadLeaderboard() {
  const response = await api.getTopRatedMovies();
  state.leaderboard = response.movies;
}

async function renderCurrentRoute() {
  const hash = window.location.hash || '#/home';
  syncAuthButton();

  try {
    if (hash.startsWith('#/movie/')) {
      const movieId = hash.split('/')[2];
      await loadMovieDetails(movieId);
      appView.innerHTML = renderMovieDetailsPage(state.selectedMovie, state.reviews, state.session?.user);
      bindMovieDetailsEvents();
      return;
    }

    if (hash === '#/leaderboard') {
      await loadLeaderboard();
      appView.innerHTML = renderLeaderboardPage(state.leaderboard);
      bindMovieCards(appView);
      return;
    }

    if (hash === '#/auth') {
      appView.innerHTML = renderAuthPage();
      bindAuthEvents();
      return;
    }

    await loadHomeData();
    appView.innerHTML = renderHomePage(state.homeData, state.searchResults, state.session?.user);
    bindHomeEvents();
    bindMovieCards(appView);
  } catch (error) {
    appView.innerHTML = `
      <section class="empty-state full-height">
        <h2>Something went wrong</h2>
        <p>${error.message}</p>
      </section>
    `;
  }
}

function bindMovieCards(scope) {
  scope.querySelectorAll('[data-movie-id]').forEach((card) => {
    card.addEventListener('click', () => {
      window.location.hash = `#/movie/${card.dataset.movieId}`;
    });
  });
}

function bindAuthEvents() {
  const registerForm = document.getElementById('registerForm');
  const loginForm = document.getElementById('loginForm');

  registerForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(registerForm).entries());
    try {
      const data = await api.register(payload);
      saveSession(data);
      state.session = data;
      showToast('Registration successful.', 'success');
      window.location.hash = '#/home';
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  loginForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(loginForm).entries());
    try {
      const data = await api.login(payload);
      saveSession(data);
      state.session = data;
      showToast('Login successful.', 'success');
      window.location.hash = '#/home';
    } catch (error) {
      showToast(error.message, 'error');
    }
  });
}

function bindHomeEvents() {
  const movieForm = document.getElementById('movieForm');
  movieForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(movieForm).entries());
    payload.release_year = Number(payload.release_year);

    try {
      await api.createMovie(payload);
      showToast('Movie added successfully.', 'success');
      movieForm.reset();
      await loadHomeData();
      appView.innerHTML = renderHomePage(state.homeData, state.searchResults, state.session?.user);
      bindHomeEvents();
      bindMovieCards(appView);
    } catch (error) {
      showToast(error.message, 'error');
    }
  });
}

function bindMovieDetailsEvents() {
  const reviewForm = document.getElementById('reviewForm');
  const reviewEditButtons = document.querySelectorAll('[data-review-edit]');
  const reviewDeleteButtons = document.querySelectorAll('[data-review-delete]');

  reviewForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(reviewForm).entries());
    payload.movie_id = state.selectedMovie._id;
    payload.rating = Number(payload.rating);
    try {
      await api.createReview(payload);
      showToast('Review saved successfully.', 'success');
      await loadMovieDetails(state.selectedMovie._id);
      appView.innerHTML = renderMovieDetailsPage(state.selectedMovie, state.reviews, state.session?.user);
      bindMovieDetailsEvents();
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  reviewEditButtons.forEach((button) => {
    button.addEventListener('click', async () => {
      const reviewId = button.dataset.reviewEdit;
      const currentText = button.dataset.reviewText;
      const currentRating = button.dataset.reviewRating;
      const nextRating = window.prompt('Update rating (1-5):', currentRating);
      const nextText = window.prompt('Update review text:', currentText);
      if (!nextRating || !nextText) {
        return;
      }
      try {
        await api.updateReview(reviewId, { rating: Number(nextRating), review_text: nextText });
        showToast('Review updated successfully.', 'success');
        await loadMovieDetails(state.selectedMovie._id);
        appView.innerHTML = renderMovieDetailsPage(state.selectedMovie, state.reviews, state.session?.user);
        bindMovieDetailsEvents();
      } catch (error) {
        showToast(error.message, 'error');
      }
    });
  });

  reviewDeleteButtons.forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await api.deleteReview(button.dataset.reviewDelete);
        showToast('Review deleted successfully.', 'success');
        await loadMovieDetails(state.selectedMovie._id);
        appView.innerHTML = renderMovieDetailsPage(state.selectedMovie, state.reviews, state.session?.user);
        bindMovieDetailsEvents();
      } catch (error) {
        showToast(error.message, 'error');
      }
    });
  });
}

searchInput.addEventListener('input', async (event) => {
  const query = event.target.value.trim();
  if (!query) {
    state.searchResults = [];
    if ((window.location.hash || '#/home') === '#/home') {
      await renderCurrentRoute();
    }
    return;
  }

  try {
    const response = await api.searchMovies(query);
    state.searchResults = response.movies;
    if ((window.location.hash || '#/home') !== '#/auth') {
      await renderCurrentRoute();
    }
  } catch (error) {
    showToast(error.message, 'error');
  }
});

authToggleButton.addEventListener('click', async () => {
  if (isAuthenticated()) {
    clearSession();
    state.session = null;
    showToast('Logged out successfully.', 'success');
    await renderCurrentRoute();
    return;
  }
  window.location.hash = '#/auth';
});

leaderboardButton.addEventListener('click', () => {
  window.location.hash = '#/leaderboard';
});

window.addEventListener('hashchange', renderCurrentRoute);
renderCurrentRoute();
