import { createStars } from '../components/templates.js';

export function renderMovieDetailsPage(movie, reviews, currentUser) {
  const currentUserReview = reviews.find((review) => review.user_id === currentUser?._id);

  return `
    <section class="detail-layout">
      <div class="detail-hero glass-card">
        <img class="detail-poster" src="${movie.poster_url}" alt="${movie.movie_name}" />
        <div class="detail-copy">
          <p class="eyebrow">Movie Details</p>
          <h2>${movie.movie_name}</h2>
          <div class="meta-line">
            <span>${movie.genre}</span>
            <span>${movie.release_year}</span>
            <span>${movie.average_rating || 0}/5 average</span>
            <span>${movie.total_reviews || 0} reviews</span>
          </div>
          <p>${movie.description}</p>
        </div>
      </div>

      <div class="detail-grid">
        <section class="glass-card review-panel">
          <div class="row-header">
            <div>
              <p class="eyebrow">Review System</p>
              <h2>Audience Feedback</h2>
            </div>
            <span>${reviews.length} total</span>
          </div>

          ${currentUser ? `
            <form id="reviewForm" class="review-form">
              <label>
                Rating
                <select name="rating" required>
                  <option value="">Select rating</option>
                  <option value="5">5 - Excellent</option>
                  <option value="4">4 - Very Good</option>
                  <option value="3">3 - Good</option>
                  <option value="2">2 - Fair</option>
                  <option value="1">1 - Poor</option>
                </select>
              </label>
              <label>
                Review
                <textarea name="review_text" rows="4" placeholder="Share what stood out about this movie" required></textarea>
              </label>
              <button class="accent-button" type="submit">Submit Review</button>
            </form>
          ` : `
            <div class="inline-notice">Log in to add your rating and review.</div>
          `}

          ${currentUserReview ? '<p class="inline-hint">You already reviewed this movie. Use edit instead of submitting another review.</p>' : ''}
        </section>

        <section class="glass-card review-list-panel">
          <div class="review-list">
            ${reviews.map((review) => `
              <article class="review-card">
                <div class="review-head">
                  <div>
                    <h3>${review.user_name}</h3>
                    <div class="stars">${createStars(review.rating)}</div>
                  </div>
                  <div class="review-date">${new Date(review.createdAt).toLocaleDateString()}</div>
                </div>
                <p>${review.review_text}</p>
                ${currentUser?._id === review.user_id ? `
                  <div class="review-actions">
                    <button
                      class="ghost-button small-button"
                      data-review-edit="${review._id}"
                      data-review-rating="${review.rating}"
                      data-review-text="${review.review_text.replace(/"/g, '&quot;')}"
                    >Edit</button>
                    <button class="ghost-button small-button danger" data-review-delete="${review._id}">Delete</button>
                  </div>
                ` : ''}
              </article>
            `).join('') || '<div class="empty-inline">No reviews yet. Be the first to rate this movie.</div>'}
          </div>
        </section>
      </div>
    </section>
  `;
}
