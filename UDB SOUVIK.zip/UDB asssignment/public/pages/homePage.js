import { sectionRow } from '../components/templates.js';

export function renderHomePage(homeData, searchResults, currentUser) {
  const featured = homeData?.featured;
  const searchBlock = searchResults.length
    ? `
      <section class="content-row search-results">
        <div class="row-header">
          <h2>Search Results</h2>
          <span>${searchResults.length} matches</span>
        </div>
        <div class="card-row">
          ${searchResults.map((movie) => `
            <article class="movie-card" data-movie-id="${movie._id}">
              <img src="${movie.poster_url}" alt="${movie.movie_name}" />
              <div class="movie-card-overlay">
                <p class="movie-card-genre">${movie.genre} | ${movie.release_year}</p>
                <h3>${movie.movie_name}</h3>
                <p>${movie.description}</p>
              </div>
            </article>
          `).join('')}
        </div>
      </section>
    `
    : '';

  const movieForm = currentUser
    ? `
      <section class="glass-card admin-panel">
        <div class="row-header">
          <div>
            <p class="eyebrow">Movie CRUD</p>
            <h2>Add a New Movie</h2>
          </div>
          <span>Protected route</span>
        </div>
        <form id="movieForm" class="movie-form-grid">
          <label>
            Movie Name
            <input type="text" name="movie_name" required />
          </label>
          <label>
            Genre
            <input type="text" name="genre" required />
          </label>
          <label>
            Release Year
            <input type="number" name="release_year" min="1900" max="2100" required />
          </label>
          <label>
            Poster URL
            <input type="url" name="poster_url" required />
          </label>
          <label class="full-width">
            Description
            <textarea name="description" rows="4" required></textarea>
          </label>
          <button class="accent-button" type="submit">Add Movie</button>
        </form>
      </section>
    `
    : '';

  return `
    <section class="hero-banner" style="background-image: linear-gradient(90deg, rgba(12, 12, 12, 0.92), rgba(12, 12, 12, 0.38)), url('${featured?.poster_url || ''}');">
      <div class="hero-copy">
        <p class="eyebrow">Featured Tonight</p>
        <h2>${featured?.movie_name || 'No featured movie yet'}</h2>
        <p>${featured?.description || 'Add movies and reviews to bring the catalog to life.'}</p>
        <div class="hero-meta">
          <span>${featured?.genre || 'Catalog pending'}</span>
          <span>${featured?.release_year || '----'}</span>
        </div>
      </div>
    </section>

    ${searchBlock}
    ${sectionRow('Top Rated', homeData?.topRated || [])}
    ${sectionRow('Trending', homeData?.trending || [])}
    ${sectionRow('Latest Releases', homeData?.latest || [])}
    ${movieForm}
  `;
}
