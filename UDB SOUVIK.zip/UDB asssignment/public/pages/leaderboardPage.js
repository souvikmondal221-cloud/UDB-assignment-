import { createStars } from '../components/templates.js';

export function renderLeaderboardPage(movies) {
  return `
    <section class="leaderboard-shell">
      <div class="row-header leaderboard-header">
        <div>
          <p class="eyebrow">Aggregation Output</p>
          <h2>Top Rated Movies</h2>
        </div>
        <span>Sorted by average rating</span>
      </div>

      <div class="leaderboard-grid">
        ${movies.map((movie, index) => `
          <article class="glass-card leaderboard-card" data-movie-id="${movie._id}">
            <span class="rank-badge">#${index + 1}</span>
            <img src="${movie.poster_url}" alt="${movie.movie_name}" />
            <div>
              <h3>${movie.movie_name}</h3>
              <p>${movie.genre} | ${movie.release_year}</p>
            </div>
            <div class="stars compact">${createStars(movie.average_rating)}</div>
            <div class="leaderboard-metrics">
              <span>${movie.average_rating}/5</span>
              <span>${movie.total_reviews} reviews</span>
            </div>
          </article>
        `).join('') || '<div class="empty-inline">Leaderboard will appear once reviews are available.</div>'}
      </div>
    </section>
  `;
}
