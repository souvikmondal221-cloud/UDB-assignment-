export function renderAuthPage() {
  return `
    <section class="auth-layout">
      <div class="auth-panel spotlight-panel">
        <p class="eyebrow">JWT Authentication</p>
        <h2>Secure access for reviews, profile data, and movie management.</h2>
        <p>
          Register a new account or log in with your existing credentials. Tokens are stored client-side and removed on logout.
        </p>
      </div>

      <div class="auth-grid">
        <form id="registerForm" class="glass-card auth-form">
          <div>
            <p class="eyebrow">Create account</p>
            <h3>Register</h3>
          </div>
          <label>
            Name
            <input type="text" name="name" placeholder="Enter your name" required />
          </label>
          <label>
            Email
            <input type="email" name="email" placeholder="name@example.com" required />
          </label>
          <label>
            Password
            <input type="password" name="password" placeholder="Minimum 6 characters" required />
          </label>
          <button class="accent-button" type="submit">Register</button>
        </form>

        <form id="loginForm" class="glass-card auth-form">
          <div>
            <p class="eyebrow">Welcome back</p>
            <h3>Login</h3>
          </div>
          <label>
            Email
            <input type="email" name="email" placeholder="name@example.com" required />
          </label>
          <label>
            Password
            <input type="password" name="password" placeholder="Enter your password" required />
          </label>
          <button class="accent-button" type="submit">Login</button>
        </form>
      </div>
    </section>
  `;
}
