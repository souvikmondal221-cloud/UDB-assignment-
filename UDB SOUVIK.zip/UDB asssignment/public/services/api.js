import { getSession } from './session.js';

async function request(url, options = {}) {
  const session = getSession();
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  if (session?.token) {
    headers.Authorization = `Bearer ${session.token}`;
  }

  const response = await fetch(url, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || data.message || 'Request failed.');
  }
  return data;
}

export const api = {
  register: (payload) => request('/auth/register', { method: 'POST', body: JSON.stringify(payload) }),
  login: (payload) => request('/auth/login', { method: 'POST', body: JSON.stringify(payload) }),
  profile: () => request('/auth/profile'),
  getHomeSections: () => request('/movies/home'),
  getMovies: () => request('/movies'),
  getMovie: (movieId) => request(`/movies/${movieId}`),
  createMovie: (payload) => request('/movies', { method: 'POST', body: JSON.stringify(payload) }),
  searchMovies: (query) => request(`/movies/search?q=${encodeURIComponent(query)}`),
  getTopRatedMovies: () => request('/movies/top-rated'),
  getMovieReviews: (movieId) => request(`/reviews/${movieId}`),
  createReview: (payload) => request('/reviews', { method: 'POST', body: JSON.stringify(payload) }),
  updateReview: (reviewId, payload) => request(`/reviews/${reviewId}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteReview: (reviewId) => request(`/reviews/${reviewId}`, { method: 'DELETE' })
};
