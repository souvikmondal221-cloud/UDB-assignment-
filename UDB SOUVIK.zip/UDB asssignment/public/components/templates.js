export function createStars(rating) {
  return Array.from({ length: 5 }, (_, index) => `
    <span class="star ${index < Math.round(rating) ? 'filled' : ''}">&#9733;</span>
  `).join('');
}

export function movieCard(movie) {
  return `
    <article class="movie-card" data-movie-id="${movie._id}">
      <img src="${movie.poster_url}" alt="${movie.movie_name}" />
      <div class="movie-card-overlay">
        <p class="movie-card-genre">${movie.genre} | ${movie.release_year}</p>
        <h3>${movie.movie_name}</h3>
        <p>${movie.description}</p>
        <div class="rating-row">
          <span>${movie.average_rating || 'New'}</span>
          <span>${movie.total_reviews || 0} reviews</span>
        </div>
      </div>
    </article>
  `;
}

export function sectionRow(title, movies) {
  return `
    <section class="content-row">
      <div class="row-header">
        <h2>${title}</h2>
        <span>${movies.length} titles</span>
      </div>
      <div class="card-row">
        ${movies.map(movieCard).join('') || '<p class="empty-inline">No movies available yet.</p>'}
      </div>
    </section>
  `;
}
