from flask import Blueprint

from controllers.auth_controller import get_profile, login_user, register_user
from middleware.auth_middleware import token_required

auth_bp = Blueprint("auth", __name__)

auth_bp.post("/register")(register_user)
auth_bp.post("/login")(login_user)
auth_bp.get("/profile")(token_required(get_profile))
