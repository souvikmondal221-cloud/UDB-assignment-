from flask import Blueprint

from controllers.reviews_controller import create_review, delete_review, get_reviews_for_movie, update_review
from middleware.auth_middleware import token_required

reviews_bp = Blueprint("reviews", __name__)

reviews_bp.post("")(token_required(create_review))
reviews_bp.put("/<review_id>")(token_required(update_review))
reviews_bp.delete("/<review_id>")(token_required(delete_review))
reviews_bp.get("/<movie_id>")(get_reviews_for_movie)
