from flask import Blueprint

from controllers.movies_controller import (
    create_movie,
    delete_movie,
    get_home_sections,
    get_movie,
    get_movies,
    get_top_rated_movies,
    search_movies,
    update_movie,
)
from middleware.auth_middleware import token_required

movies_bp = Blueprint("movies", __name__)

movies_bp.get("")(get_movies)
movies_bp.post("")(token_required(create_movie))
movies_bp.get("/home")(get_home_sections)
movies_bp.get("/search")(search_movies)
movies_bp.get("/top-rated")(get_top_rated_movies)
movies_bp.get("/<movie_id>")(get_movie)
movies_bp.put("/<movie_id>")(token_required(update_movie))
movies_bp.delete("/<movie_id>")(token_required(delete_movie))
