from functools import wraps

from bson import ObjectId
import jwt
from flask import g, jsonify, request
from jwt import ExpiredSignatureError, InvalidTokenError

from config.settings import JWT_SECRET_KEY
from models.user_model import get_users_collection, serialize_user


def token_required(handler):
    @wraps(handler)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"error": "Authorization token is missing."}), 401

        token = auth_header.split(" ", 1)[1]

        try:
            payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=["HS256"])
        except ExpiredSignatureError:
            return jsonify({"error": "Token has expired. Please log in again."}), 401
        except InvalidTokenError:
            return jsonify({"error": "Invalid authentication token."}), 401

        user_id = payload.get("user_id")
        if not user_id or not ObjectId.is_valid(user_id):
            return jsonify({"error": "Invalid authentication payload."}), 401

        user = get_users_collection().find_one({"_id": ObjectId(user_id)})
        if not user:
            return jsonify({"error": "User not found."}), 404

        g.current_user = serialize_user(user)
        return handler(*args, **kwargs)

    return decorated
