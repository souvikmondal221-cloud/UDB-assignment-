from config.db import db
from models.base_model import serialize_document


def get_movies_collection():
    return db.movies


def serialize_movie(movie):
    return serialize_document(movie)
