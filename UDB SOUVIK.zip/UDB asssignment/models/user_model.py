from config.db import db
from models.base_model import serialize_document


def get_users_collection():
    return db.users


def serialize_user(user):
    return serialize_document(user)
