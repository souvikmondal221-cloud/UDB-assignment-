from config.db import db
from models.base_model import serialize_document


def get_reviews_collection():
    return db.reviews


def serialize_review(review):
    return serialize_document(review)
