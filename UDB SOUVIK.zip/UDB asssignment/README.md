# Movie Recommendation & Review System

Full-stack movie recommendation and review application with:

- Frontend: HTML, CSS, JavaScript
- Backend: Python (Flask)
- Database: MongoDB
- Auth: JWT + bcrypt

Note: Your original prompt mentioned `Mongoose`, but because the backend is Python this project uses `PyMongo`, which is the correct MongoDB driver for Flask applications.

## Project Structure

```
config/
controllers/
middleware/
models/
public/
  components/
  pages/
  services/
routes/
app.py
requirements.txt
package.json
.env.example
```

## Features

- User registration and login
- JWT protected routes
- MongoDB text search on movie titles
- Movie CRUD APIs
- Review CRUD APIs
- Aggregation APIs for average ratings and top-rated movies
- Netflix-style frontend with banner, scrolling rows, detail page, reviews, and leaderboard

## MongoDB Collections

### `users`

```json
{
  "name": "String",
  "email": "String",
  "password": "String",
  "createdAt": "Date"
}
```

### `movies`

```json
{
  "movie_name": "String",
  "genre": "String",
  "release_year": 2024,
  "description": "String",
  "poster_url": "String",
  "createdAt": "Date"
}
```

### `reviews`

```json
{
  "user_id": "ObjectId",
  "movie_id": "ObjectId",
  "rating": 5,
  "review_text": "String",
  "createdAt": "Date"
}
```

## Indexes

The app creates these indexes automatically during startup:

- `db.movies.createIndex({ movie_name: "text" })`
- unique index on `users.email`
- indexes on `reviews.movie_id` and `reviews.user_id`

## Setup

1. Install Python dependencies:

```bash
pip install -r requirements.txt
```

2. Create your environment file:

```bash
copy .env.example .env
```

3. Make sure MongoDB is running locally or update `MONGO_URI` in `.env`.

4. Start the app:

```bash
npm install
npm start
```

The app runs on [http://localhost:5000](http://localhost:5000).

## Environment Variables

```env
FLASK_ENV=development
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017
MONGO_DB_NAME=movie_recommendation_review_system
JWT_SECRET_KEY=change-this-secret-key
JWT_EXPIRES_IN_HOURS=24
AUTO_SEED=true
```

## API Endpoints

### Auth

- `POST /auth/register`
- `POST /auth/login`
- `GET /auth/profile`

### Movies

- `POST /movies`
- `GET /movies`
- `GET /movies/:id`
- `PUT /movies/:id`
- `DELETE /movies/:id`
- `GET /movies/search?q=keyword`
- `GET /movies/top-rated`
- `GET /movies/home`

### Reviews

- `POST /reviews`
- `PUT /reviews/:id`
- `DELETE /reviews/:id`
- `GET /reviews/:movieId`

## Aggregation Queries

### Average rating per movie

```javascript
db.reviews.aggregate([
  {
    $group: {
      _id: "$movie_id",
      average_rating: { $avg: "$rating" },
      total_reviews: { $sum: 1 }
    }
  }
])
```

### Top-rated movies leaderboard

```javascript
db.reviews.aggregate([
  {
    $group: {
      _id: "$movie_id",
      average_rating: { $avg: "$rating" },
      total_reviews: { $sum: 1 }
    }
  },
  { $sort: { average_rating: -1, total_reviews: -1 } },
  { $limit: 10 },
  {
    $lookup: {
      from: "movies",
      localField: "_id",
      foreignField: "_id",
      as: "movie"
    }
  },
  { $unwind: "$movie" }
])
```

## Postman Examples

### Register

`POST /auth/register`

```json
{
  "name": "Aarav Mehta",
  "email": "aarav@example.com",
  "password": "secret123"
}
```

### Login

`POST /auth/login`

```json
{
  "email": "aarav@example.com",
  "password": "secret123"
}
```

### Add Movie

`POST /movies`

Headers:

```
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json
```

Body:

```json
{
  "movie_name": "Midnight Signal",
  "genre": "Thriller",
  "release_year": 2026,
  "description": "A radio host discovers each late-night caller is predicting a real crime.",
  "poster_url": "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?auto=format&fit=crop&w=800&q=80"
}
```

### Search Movies

`GET /movies/search?q=midnight`

### Add Review

`POST /reviews`

```json
{
  "movie_id": "<MOVIE_ID>",
  "rating": 5,
  "review_text": "Excellent pacing and a strong ending."
}
```
