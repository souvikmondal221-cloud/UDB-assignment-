from pymongo import MongoClient, TEXT
from pymongo.errors import OperationFailure

from config.settings import AUTO_SEED, MONGO_DB_NAME, MONGO_URI

client = MongoClient(MONGO_URI)
db = client[MONGO_DB_NAME]

SAMPLE_MOVIES = [
    {
        "movie_name": "The Silent Orbit",
        "genre": "Sci-Fi",
        "release_year": 2024,
        "description": "A mission to the edge of the solar system uncovers a signal that can rewrite human memory.",
        "poster_url": "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=800&q=80"
    },
    {
        "movie_name": "Monsoon Letters",
        "genre": "Romance",
        "release_year": 2023,
        "description": "Two writers in Mumbai fall in love through anonymous letters during an unforgettable rainy season.",
        "poster_url": "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80"
    },
    {
        "movie_name": "Iron Verdict",
        "genre": "Action",
        "release_year": 2022,
        "description": "A suspended officer races through a corrupt city to stop a private militia from taking control.",
        "poster_url": "https://images.unsplash.com/photo-1518998053901-5348d3961a04?auto=format&fit=crop&w=800&q=80"
    },
    {
        "movie_name": "Afterlight Avenue",
        "genre": "Drama",
        "release_year": 2025,
        "description": "An aging theatre owner fights to keep her cinema alive as the neighborhood around it transforms overnight.",
        "poster_url": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&w=800&q=80"
    },
    {
        "movie_name": "Pixel Raiders",
        "genre": "Adventure",
        "release_year": 2021,
        "description": "A speedrunner and a game historian discover clues to a fortune hidden inside a forgotten arcade classic.",
        "poster_url": "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?auto=format&fit=crop&w=800&q=80"
    }
]


def bootstrap_database():
    try:
        db.movies.create_index([("movie_name", TEXT)], name="movie_name_text_index")
    except OperationFailure as error:
        if getattr(error, "code", None) != 85:
            raise
    db.reviews.create_index("movie_id")
    db.reviews.create_index("user_id")
    db.users.create_index("email", unique=True)

    if AUTO_SEED and db.movies.count_documents({}) == 0:
        db.movies.insert_many(SAMPLE_MOVIES)
