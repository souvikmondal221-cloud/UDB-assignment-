// Deprecated: the app now starts from app.py via `npm start`.
