from datetime import datetime

from bson import ObjectId
from flask import jsonify, request

from models.movie_model import get_movies_collection, serialize_movie
from models.review_model import get_reviews_collection


def _is_valid_object_id(value):
    return ObjectId.is_valid(value)


def create_movie():
    payload = request.get_json(silent=True) or {}
    movie_name = str(payload.get("movie_name", "")).strip()
    genre = str(payload.get("genre", "")).strip()
    description = str(payload.get("description", "")).strip()
    poster_url = str(payload.get("poster_url", "")).strip()

    try:
        release_year = int(payload.get("release_year", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "Release year must be a number."}), 400

    if not movie_name:
        return jsonify({"error": "Movie name is required."}), 400
    if not genre:
        return jsonify({"error": "Genre is required."}), 400
    if release_year <= 1800:
        return jsonify({"error": "Release year must be valid."}), 400
    if len(description) < 10:
        return jsonify({"error": "Description must be at least 10 characters."}), 400

    movie = {
        "movie_name": movie_name,
        "genre": genre,
        "release_year": release_year,
        "description": description,
        "poster_url": poster_url,
        "createdAt": datetime.utcnow().isoformat()
    }
    result = get_movies_collection().insert_one(movie)
    created_movie = get_movies_collection().find_one({"_id": result.inserted_id})
    return jsonify({"message": "Movie added successfully.", "movie": serialize_movie(created_movie)}), 201


def get_movies():
    movies = [serialize_movie(movie) for movie in get_movies_collection().find().sort("createdAt", -1)]
    return jsonify({"movies": movies})


def get_movie(movie_id):
    if not _is_valid_object_id(movie_id):
        return jsonify({"error": "Invalid movie id."}), 400

    movie = get_movies_collection().find_one({"_id": ObjectId(movie_id)})
    if not movie:
        return jsonify({"error": "Movie not found."}), 404

    rating_summary = next(get_reviews_collection().aggregate([
        {"$match": {"movie_id": ObjectId(movie_id)}},
        {
            "$group": {
                "_id": "$movie_id",
                "average_rating": {"$avg": "$rating"},
                "total_reviews": {"$sum": 1}
            }
        }
    ]), None)

    response_movie = serialize_movie(movie)
    response_movie["average_rating"] = round(rating_summary["average_rating"], 1) if rating_summary else 0
    response_movie["total_reviews"] = rating_summary["total_reviews"] if rating_summary else 0
    return jsonify({"movie": response_movie})


def update_movie(movie_id):
    if not _is_valid_object_id(movie_id):
        return jsonify({"error": "Invalid movie id."}), 400

    payload = request.get_json(silent=True) or {}
    update_fields = {}
    for field in ["movie_name", "genre", "description", "poster_url"]:
        if field in payload:
            update_fields[field] = str(payload.get(field, "")).strip()
    if "release_year" in payload:
        try:
            update_fields["release_year"] = int(payload["release_year"])
        except (TypeError, ValueError):
            return jsonify({"error": "Release year must be a number."}), 400

    if not update_fields:
        return jsonify({"error": "No fields provided for update."}), 400

    result = get_movies_collection().update_one({"_id": ObjectId(movie_id)}, {"$set": update_fields})
    if result.matched_count == 0:
        return jsonify({"error": "Movie not found."}), 404

    movie = get_movies_collection().find_one({"_id": ObjectId(movie_id)})
    return jsonify({"message": "Movie updated successfully.", "movie": serialize_movie(movie)})


def delete_movie(movie_id):
    if not _is_valid_object_id(movie_id):
        return jsonify({"error": "Invalid movie id."}), 400

    result = get_movies_collection().delete_one({"_id": ObjectId(movie_id)})
    if result.deleted_count == 0:
        return jsonify({"error": "Movie not found."}), 404

    get_reviews_collection().delete_many({"movie_id": ObjectId(movie_id)})
    return jsonify({"message": "Movie deleted successfully."})


def search_movies():
    keyword = str(request.args.get("q", "")).strip()
    if not keyword:
        return jsonify({"movies": []})

    movies = [serialize_movie(movie) for movie in get_movies_collection().aggregate([
        {"$match": {"$text": {"$search": keyword}}},
        {"$addFields": {"score": {"$meta": "textScore"}}},
        {"$sort": {"score": -1}}
    ])]
    return jsonify({"movies": movies})


def get_top_rated_movies():
    pipeline = [
        {
            "$group": {
                "_id": "$movie_id",
                "average_rating": {"$avg": "$rating"},
                "total_reviews": {"$sum": 1}
            }
        },
        {"$sort": {"average_rating": -1, "total_reviews": -1}},
        {"$limit": 10},
        {
            "$lookup": {
                "from": "movies",
                "localField": "_id",
                "foreignField": "_id",
                "as": "movie"
            }
        },
        {"$unwind": "$movie"},
        {
            "$project": {
                "_id": {"$toString": "$movie._id"},
                "movie_name": "$movie.movie_name",
                "genre": "$movie.genre",
                "release_year": "$movie.release_year",
                "description": "$movie.description",
                "poster_url": "$movie.poster_url",
                "average_rating": {"$round": ["$average_rating", 1]},
                "total_reviews": 1
            }
        }
    ]
    leaderboard = list(get_reviews_collection().aggregate(pipeline))
    return jsonify({"movies": leaderboard})


def get_home_sections():
    top_rated = list(get_reviews_collection().aggregate([
        {
            "$group": {
                "_id": "$movie_id",
                "average_rating": {"$avg": "$rating"},
                "total_reviews": {"$sum": 1}
            }
        },
        {"$sort": {"average_rating": -1, "total_reviews": -1}},
        {"$limit": 10},
        {
            "$lookup": {
                "from": "movies",
                "localField": "_id",
                "foreignField": "_id",
                "as": "movie"
            }
        },
        {"$unwind": "$movie"},
        {
            "$project": {
                "_id": {"$toString": "$movie._id"},
                "movie_name": "$movie.movie_name",
                "genre": "$movie.genre",
                "release_year": "$movie.release_year",
                "description": "$movie.description",
                "poster_url": "$movie.poster_url",
                "average_rating": {"$round": ["$average_rating", 1]},
                "total_reviews": 1
            }
        }
    ]))

    latest = [serialize_movie(movie) for movie in get_movies_collection().find().sort("release_year", -1).limit(10)]

    trending = list(get_reviews_collection().aggregate([
        {
            "$group": {
                "_id": "$movie_id",
                "average_rating": {"$avg": "$rating"},
                "total_reviews": {"$sum": 1}
            }
        },
        {"$sort": {"total_reviews": -1, "average_rating": -1}},
        {"$limit": 10},
        {
            "$lookup": {
                "from": "movies",
                "localField": "_id",
                "foreignField": "_id",
                "as": "movie"
            }
        },
        {"$unwind": "$movie"},
        {
            "$project": {
                "_id": {"$toString": "$movie._id"},
                "movie_name": "$movie.movie_name",
                "genre": "$movie.genre",
                "release_year": "$movie.release_year",
                "description": "$movie.description",
                "poster_url": "$movie.poster_url",
                "average_rating": {"$round": ["$average_rating", 1]},
                "total_reviews": 1
            }
        }
    ]))

    fallback_featured = get_movies_collection().find_one(sort=[("release_year", -1), ("createdAt", -1)])
    featured = None
    if top_rated:
        featured = get_movies_collection().find_one({"_id": ObjectId(top_rated[0]["_id"])})
    elif fallback_featured:
        featured = fallback_featured

    featured_payload = serialize_movie(featured) if featured else None
    return jsonify({
        "featured": featured_payload,
        "topRated": top_rated,
        "latest": latest,
        "trending": trending
    })
