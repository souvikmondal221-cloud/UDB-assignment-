from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from flask import g, jsonify, request
from pymongo.errors import DuplicateKeyError

from config.settings import JWT_EXPIRES_IN_HOURS, JWT_SECRET_KEY
from models.user_model import get_users_collection, serialize_user


def _build_token(user_id):
    expires_at = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRES_IN_HOURS)
    return jwt.encode(
        {"user_id": str(user_id), "exp": expires_at},
        JWT_SECRET_KEY,
        algorithm="HS256"
    )


def register_user():
    payload = request.get_json(silent=True) or {}
    name = str(payload.get("name", "")).strip()
    email = str(payload.get("email", "")).strip().lower()
    password = str(payload.get("password", "")).strip()

    if len(name) < 2:
        return jsonify({"error": "Name must be at least 2 characters."}), 400
    if "@" not in email:
        return jsonify({"error": "A valid email is required."}), 400
    if len(password) < 6:
        return jsonify({"error": "Password must be at least 6 characters."}), 400

    password_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    user = {
        "name": name,
        "email": email,
        "password": password_hash,
        "createdAt": datetime.utcnow().isoformat()
    }

    try:
        result = get_users_collection().insert_one(user)
    except DuplicateKeyError:
        return jsonify({"error": "An account with this email already exists."}), 409

    created_user = get_users_collection().find_one({"_id": result.inserted_id})
    response_user = serialize_user(created_user)
    response_user.pop("password", None)

    return jsonify({
        "message": "Registration successful.",
        "token": _build_token(result.inserted_id),
        "user": response_user
    }), 201


def login_user():
    payload = request.get_json(silent=True) or {}
    email = str(payload.get("email", "")).strip().lower()
    password = str(payload.get("password", "")).strip()

    user = get_users_collection().find_one({"email": email})
    if not user:
        return jsonify({"error": "Invalid email or password."}), 401

    if not bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8")):
        return jsonify({"error": "Invalid email or password."}), 401

    response_user = serialize_user(user)
    response_user.pop("password", None)

    return jsonify({
        "message": "Login successful.",
        "token": _build_token(user["_id"]),
        "user": response_user
    })


def get_profile():
    user = dict(g.current_user)
    user.pop("password", None)
    return jsonify({"user": user})
