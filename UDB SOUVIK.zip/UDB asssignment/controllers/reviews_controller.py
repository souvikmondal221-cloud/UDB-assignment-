from datetime import datetime

from bson import ObjectId
from flask import g, jsonify, request

from models.movie_model import get_movies_collection
from models.review_model import get_reviews_collection, serialize_review


def _valid_object_id(value):
    return ObjectId.is_valid(value)


def create_review():
    payload = request.get_json(silent=True) or {}
    movie_id = str(payload.get("movie_id", "")).strip()
    review_text = str(payload.get("review_text", "")).strip()

    try:
        rating = int(payload.get("rating", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "Rating must be a number between 1 and 5."}), 400

    if not _valid_object_id(movie_id):
        return jsonify({"error": "Invalid movie id."}), 400
    if rating < 1 or rating > 5:
        return jsonify({"error": "Rating must be between 1 and 5."}), 400
    if len(review_text) < 5:
        return jsonify({"error": "Review text must be at least 5 characters."}), 400
    if not get_movies_collection().find_one({"_id": ObjectId(movie_id)}):
        return jsonify({"error": "Movie not found."}), 404

    user_id = ObjectId(g.current_user["_id"])
    existing_review = get_reviews_collection().find_one({"user_id": user_id, "movie_id": ObjectId(movie_id)})
    if existing_review:
        return jsonify({"error": "You have already reviewed this movie. Please update the existing review instead."}), 409

    review = {
        "user_id": user_id,
        "movie_id": ObjectId(movie_id),
        "rating": rating,
        "review_text": review_text,
        "createdAt": datetime.utcnow().isoformat()
    }
    result = get_reviews_collection().insert_one(review)
    created_review = get_reviews_collection().find_one({"_id": result.inserted_id})
    return jsonify({"message": "Review added successfully.", "review": serialize_review(created_review)}), 201


def update_review(review_id):
    if not _valid_object_id(review_id):
        return jsonify({"error": "Invalid review id."}), 400

    payload = request.get_json(silent=True) or {}
    update_fields = {}

    if "rating" in payload:
        try:
            rating = int(payload["rating"])
        except (TypeError, ValueError):
            return jsonify({"error": "Rating must be a number between 1 and 5."}), 400
        if rating < 1 or rating > 5:
            return jsonify({"error": "Rating must be between 1 and 5."}), 400
        update_fields["rating"] = rating

    if "review_text" in payload:
        review_text = str(payload["review_text"]).strip()
        if len(review_text) < 5:
            return jsonify({"error": "Review text must be at least 5 characters."}), 400
        update_fields["review_text"] = review_text

    if not update_fields:
        return jsonify({"error": "No fields provided for update."}), 400

    review = get_reviews_collection().find_one({"_id": ObjectId(review_id)})
    if not review:
        return jsonify({"error": "Review not found."}), 404
    if str(review["user_id"]) != g.current_user["_id"]:
        return jsonify({"error": "You can update only your own reviews."}), 403

    get_reviews_collection().update_one({"_id": ObjectId(review_id)}, {"$set": update_fields})
    updated_review = get_reviews_collection().find_one({"_id": ObjectId(review_id)})
    return jsonify({"message": "Review updated successfully.", "review": serialize_review(updated_review)})


def delete_review(review_id):
    if not _valid_object_id(review_id):
        return jsonify({"error": "Invalid review id."}), 400

    review = get_reviews_collection().find_one({"_id": ObjectId(review_id)})
    if not review:
        return jsonify({"error": "Review not found."}), 404
    if str(review["user_id"]) != g.current_user["_id"]:
        return jsonify({"error": "You can delete only your own reviews."}), 403

    get_reviews_collection().delete_one({"_id": ObjectId(review_id)})
    return jsonify({"message": "Review deleted successfully."})


def get_reviews_for_movie(movie_id):
    if not _valid_object_id(movie_id):
        return jsonify({"error": "Invalid movie id."}), 400

    pipeline = [
        {"$match": {"movie_id": ObjectId(movie_id)}},
        {"$sort": {"createdAt": -1}},
        {
            "$lookup": {
                "from": "users",
                "localField": "user_id",
                "foreignField": "_id",
                "as": "user"
            }
        },
        {"$unwind": "$user"},
        {
            "$project": {
                "_id": {"$toString": "$_id"},
                "movie_id": {"$toString": "$movie_id"},
                "user_id": {"$toString": "$user_id"},
                "rating": 1,
                "review_text": 1,
                "createdAt": 1,
                "user_name": "$user.name"
            }
        }
    ]
    reviews = list(get_reviews_collection().aggregate(pipeline))
    return jsonify({"reviews": reviews})
